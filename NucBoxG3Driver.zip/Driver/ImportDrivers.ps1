#This script will install all drivers for GMKtek NucBox G3

Set-ExecutionPolicy RemoteSigned -Force

cd C:\Driver

Get-ChildItem . -Recurse -Filter "*inf" | ForEach-Object { PNPUtil.exe /add-driver $_.FullName /install }
